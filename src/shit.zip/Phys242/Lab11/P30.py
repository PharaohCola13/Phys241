# Spencer Riley

## Note: If you just want the numerical results of the parts,
## then just uncomment all of the function callers at the end of the
## code. The visual result will be all of the parts superimposed
## on each other. Part C will have to be uncommented manually because
## of the for loop.

from __future__ import division, print_function
from visual import *

scene.width = scene.height = 800
scene.background = color.white

## Constants
ep0     = 8.85e-12
oofpez  = 9e9

## Creates a charge particle
charge          = sphere()
charge.pos      = vector(-0.03, 0, 0)
charge.q        = -2e-9
charge.radius   = 0.02
charge.color    = color.red

## Creates a Gaussian surface (box)
gaussian        = box()
gaussian.pos    = vector(-0.03, 0, 0)
gaussian.width  = \
	gaussian.height = \
	gaussian.length = 0.1
gaussian.opacity    = 0.5
gaussian.color      = color.cyan
gaussian.area       = 6*(gaussian.length * gaussian.width)
L   = gaussian.length
# Scale Factor for electric field
sf 	= 1e-5
# Scale Factor for Area vector
sf2 = 10

def parta():
## Observation locations
   obs     = [vector(-0.03, 0.05, 0), vector(-0.03, -0.05, 0),
			  vector(0.02, 0, 0), vector(-0.08, 0, 0),
			  vector(-0.03, 0, 0.05), vector(-0.03, 0, -0.05)]
## Initializes a list for flux integral
   flux = []
## Calculates the area vector
   dA = gaussian.area/len(obs)
##
   for i in obs:
		robs    = i - charge.pos
		rmag    = mag(robs)
		rhat    = norm(robs)
		Efield  = oofpez * (charge.q)/rmag**2 * rhat

## Electric field arrows
		earrow          = arrow()
		earrow.pos      = i
		earrow.axis     = Efield * sf
		earrow.color    = color.green

## Area vector arrows
		dAarrow 		= arrow()
		dAarrow.pos 	= i
		dAarrow.axis 	= dA * norm(Efield) * sf2
		dAarrow.color 	= color.magenta
		dAarrow.opacity = 0.3
## Computes the electric flux
		Eflux = Efield * dA
		flux.append(mag(Eflux))
## Sums over the divisions for numerical solution for electric flux
   net_flux = sum(flux)
## Analytical solution for the electric flux
   qoep0 = abs(charge.q) / ep0
   print("\t-----\tPart A\t-----")
   print("The analytical solution is {:1.3f}".format(qoep0))
   print("The numerical solution is {:1.3f}".format(net_flux))

### Part B
def partb():
	N = 2  # The square root of the number of divisions
## Used to create the observation locations for the electric field
	dx = L / N  #
	x0 = -L / 2 + dx / 2
## Initializes Index
	j = 0
## Initializes observation list
	obs = []
## Computes the observation position on every side of the cube
	while j <= N - 1:
		rate(1e10)
		k = 0
		while k <= N - 1:
			obs1 = vector(x0 * 2 + j * dx, 0.05, x0 + k * dx)
			obs2 = vector(x0 * 2 + j * dx, -0.05, x0 + k * dx)
			obs3 = vector(0.02, x0 + j * dx, x0 + k * dx)
			obs4 = vector(-0.08, x0 + j * dx, x0 + k * dx)
			obs5 = vector(x0 * 2 + k * dx, x0 + j * dx, 0.05)
			obs6 = vector(x0 * 2 + k * dx, x0 + j * dx, -0.05)
			obs.append(obs1)
			obs.append(obs2)
			obs.append(obs3)
			obs.append(obs4)
			obs.append(obs5)
			obs.append(obs6)
			k = k + 1
		j = j + 1
	## Initializes the flux list
	flux = []
## Calculates the area vector
	dA1 = gaussian.area / len(obs) * vector(1, 0, 0)
	dA2 = gaussian.area / len(obs) * vector(-1, 0, 0)
	dA3 = gaussian.area / len(obs) * vector(0, 1, 0)
	dA4 = gaussian.area / len(obs) * vector(0, -1, 0)
	dA5 = gaussian.area / len(obs) * vector(0, 0, 1)
	dA6 = gaussian.area / len(obs) * vector(0, 0, -1)
	dA_list 		= [dA1, dA2, dA3, dA4, dA5, dA6]
## Computes the electric field and electric flux
	for i in obs:
		robs 	= i - charge.pos
		rmag 	= mag(robs)
		rhat 	= norm(robs)
		Efield 	= oofpez * (charge.q)/(rmag**2) * rhat
## Used for the area vector/Electric flux calculation
		if i.z == -L/2:
			dA = dA_list[5]
		elif i.z == L/2:
			dA = dA_list[4]
		elif i.z and i.y == L/4 and i.x == -0.08:
			dA = dA_list[1]
		elif i.z and i.y == -L/4 and i.x == -0.08:
			dA = dA_list[1]
		elif i.z and i.y == L/4 and i.x == L/5:
			dA = dA_list[0]
		elif i.z and i.y == -L/4 and i.x == L/5:
			dA = dA_list[0]
		elif i.y == L/2:
			dA = dA_list[2]
		elif i.y == -L/2:
			dA = dA_list[3]
		else:
			print("Fail")

## Electric field arrows
		earrow = arrow()
		earrow.pos = i
		earrow.axis = Efield * sf
		earrow.color = color.green

## Area vector arrows
		dAarrow = arrow()
		dAarrow.pos = i
		dAarrow.axis = dA * sf2
		dAarrow.color = color.magenta
		dAarrow.opacity = 0.3
## Calculates the electric flux
		Eflux = dot(Efield,rhat) * dA
		flux.append(abs(Eflux))
## Sums the electric flux over all of the divisions
	net_flux 	= sum(flux)
## Analytical solution for the electric flux
	qoep0 = abs(charge.q) / ep0

	print("\t-----\tPart B\t-----")
	print("The analytical solution is {:1.1f}".format(qoep0))
	print("The numerical solution is {:1.1f}".format(net_flux))
	print("Difference {:1.2f}".format(net_flux-qoep0))

### Part C
def partc(n):
	N = n  # The square root of the number of divisions
## Used to create the observation locations for the electric field
	dx = L / N  #
	x0 = -L / 2 + dx / 2
## Initializes Index
	j = 0
## Initializes observation list
	obs = []
## Computes the observation position on every side of the cube
	while j <= N - 1:
		rate(1e10)
		k = 0
		while k <= N - 1:
			obs1 = vector(x0 * 2 + j * dx, 0.05, x0 + k * dx)
			obs2 = vector(x0 * 2 + j * dx, -0.05, x0 + k * dx)
			obs3 = vector(0.02, x0 + j * dx, x0 + k * dx)
			obs4 = vector(-0.08, x0 + j * dx, x0 + k * dx)
			obs5 = vector(x0 * 2 + k * dx, x0 + j * dx, 0.05)
			obs6 = vector(x0 * 2 + k * dx, x0 + j * dx, -0.05)
			obs.append(obs1)
			obs.append(obs2)
			obs.append(obs3)
			obs.append(obs4)
			obs.append(obs5)
			obs.append(obs6)
			k = k + 1
		j = j + 1
## Initializes the flux list
	flux = []
## Used for the area vector/Electric flux calculation
	dA1 = gaussian.area / len(obs) * vector(1, 0, 0)
	dA2 = gaussian.area / len(obs) * vector(-1, 0, 0)
	dA3 = gaussian.area / len(obs) * vector(0, 1, 0)
	dA4 = gaussian.area / len(obs) * vector(0, -1, 0)
	dA5 = gaussian.area / len(obs) * vector(0, 0, 1)
	dA6 = gaussian.area / len(obs) * vector(0, 0, -1)
	dA_list 		= [dA1, dA2, dA3, dA4, dA5, dA6]
	for i in obs:
		robs = i - charge.pos
		rmag 	= mag(robs)
		rhat 	= norm(robs)
		Efield 	= oofpez * (charge.q)/(rmag**2) * rhat

		if i.y and i.z <= L/2 and i.x <= -L/2-L/5 :
			dA = dA_list[1]
		elif i.z and i.y >= L/2 and i.x <= 0:
			dA = dA_list[2]
		elif i.z and i.y <= -L/2 and i.x <= 0:
			dA = dA_list[3]
		elif i.y and i.z <= -L/2:
			dA = dA_list[5]
		elif i.y and i.z <= L/2 and i.x <= -L/2 - L/5:
			dA = dA_list[1]
		elif i.y and i.z >= L/2:
			dA = dA_list[4]
		elif i.y and i.z >= -L/2 and i.x >= -L/2 + L/5 :
			dA = dA_list[0]
		else:
			pass
## Electric field arrows
		earrow = arrow()
		earrow.pos = i
		earrow.axis = Efield * sf
		earrow.color = color.green

## Area vector arrows
		dAarrow = arrow()
		dAarrow.pos = i
		dAarrow.axis = dA * sf2
		dAarrow.color = color.magenta
		dAarrow.opacity = 0.3

## Electric flux computation for each piece
		Eflux = dot(Efield, rhat) * dA
		flux.append(mag(Eflux))

## Sums the electric flux over all of the divisions
	net_flux = sum(flux)
## Analytical solution for the electric flux
	qoep0 = abs(charge.q) / ep0

	print("\t-----\tPart C (n={})\t-----".format(n))
	print("The analytical solution is {:1.1f}".format(qoep0))
	print("The numerical solution is {:1.1f}".format(net_flux))
	print("The difference is {:1.1f}".format(net_flux-qoep0))

#### Part D
def partd(w):
	N   = 2  # The square root of the number of divisions
## Used to create the observation locations for the electric field
	dx  = L/N  #
	x0  = -L/2 + dx/2
## Initializes Index
	j   = 0
## Initializes observation list
	obs = []
## Computes the observation position on every side of the cube
	while j <= N-1:
		rate(1e10)
		k = 0
		while k <= N-1:
			obs1 = vector(x0*2+ j*dx, 0.05 , x0+k*dx)
			obs2 = vector(x0*2+j*dx, -0.05, x0+k*dx)
			obs3 = vector(0.02, x0+j*dx, x0+k*dx)
			obs4 = vector(-0.08, x0+j*dx,x0+k*dx)
			obs5 = vector(x0*2+k*dx, x0+j*dx, 0.05)
			obs6 = vector(x0*2+k*dx, x0+j*dx, -0.05)
			obs.append(obs1)
			obs.append(obs2)
			obs.append(obs3)
			obs.append(obs4)
			obs.append(obs5)
			obs.append(obs6)
			k = k + 1
		j = j + 1
## Initializes the flux list
	flux = []

#### Both positions of the charge
	if w == "a":
		charge.pos = vector(-0.05, 0, 0)
	elif w == "b":
		charge.pos = vector(0.1, 0, 0)
####
## Calculates the vector area
	dA1 = gaussian.area / len(obs) * vector(1, 0, 0)
	dA2 = gaussian.area / len(obs) * vector(-1, 0, 0)
	dA3 = gaussian.area / len(obs) * vector(0, 1, 0)
	dA4 = gaussian.area / len(obs) * vector(0, -1, 0)
	dA5 = gaussian.area / len(obs) * vector(0, 0, 1)
	dA6 = gaussian.area / len(obs) * vector(0, 0, -1)
	dA_list 		= [dA1, dA2, dA3, dA4, dA5, dA6]
## Computes the electric field and electric flux
	for i in obs:
		robs 	= i - charge.pos
		rmag 	= mag(robs)
		rhat 	= norm(robs)
		Efield 	= oofpez * (charge.q) / (rmag ** 2) * rhat
## Used for area vector calculation
		if i.y and i.z <= L / 2 and i.x <= -L / 2 - L / 5:
			dA = dA_list[1]
		elif i.z and i.y >= L / 2 and i.x <= 0:
			dA = dA_list[2]
		elif i.z and i.y <= -L / 2 and i.x <= 0:
			dA = dA_list[3]
		elif i.y and i.z <= -L / 2:
			dA = dA_list[5]
		elif i.y and i.z <= L / 2 and i.x <= -L / 2 - L / 5:
			dA = dA_list[1]
		elif i.y and i.z >= L / 2:
			dA = dA_list[4]
		elif i.y and i.z >= -L / 2 and i.x >= -L / 2 + L / 5:
			dA = dA_list[0]
		else:
			print(i.x, i.y, i.z)

## Electric field arrows
		earrow = arrow()
		earrow.pos = i
		earrow.axis = Efield * sf
		earrow.color = color.green

## Area vector arrows
		dAarrow 		= arrow()
		dAarrow.pos 	= i
		dAarrow.axis 	= dA * sf2
		dAarrow.color 	= color.magenta
		dAarrow.opacity = 0.3

## Electric flux computation for each piece
		Eflux = dot(Efield, rhat) * dA
		flux.append(mag(Eflux))

## Sums the electric flux over all of the divisions
	net_flux 	= sum(flux)
## Calculates analytical solution for electric flux
	if charge.pos.x >= 0.07:
		charge.q = 0
		qoep0 = abs(charge.q)/ep0
	else:
		qoep0 = abs(charge.q)/ep0

	print("\t-----\tPart D\t-----")
	print("The analytical solution is {:1.1f}".format(qoep0))
	print("The numerical solution is {:1.1f}".format(net_flux))
	print("The difference is {:1.1f}".format(net_flux - qoep0))


#parta()
partb()
#for n in range(2, 50):
#	partc(n)
#partd("a")
#partd("b")