# Spencer Riley
from __future__ import division, print_function
from visual import *

scene = display(
	title="Problem 89 Modified",
	background=color.white)

scene.autoscale = True

oofpez  = 9e9  #[Nm^2/C^2]
# Total length of the rod of the charge
L       = 0.05 #[m]
# Total Charge
Qtot    = -2e-8 #[C]
# Number of spheres
N       = 50

# Used for the placement of the spheres
dx      = L/N   #[m/charge]
x0      = -L/2 + dx/2

sources = []
# Initializes index
i       = 0
# Creates the rod of charge with spheres
while i < N:
	a = sphere()
	a.pos = vector(0, x0+i*dx, 0)
	a.radius = dx
	a.color = color.red
	a.q     = Qtot/N

	sources.append(a)
	i = i + 1

# Path of potential
A = vector(0.02, 0.02, 0)
B = vector(0.12, 0.08, 0)

# Initial value for the potential
VA = 0
VB = 0


# Initializes the index
i = 0
# Calculates the potential at the defined locations
while i < len(sources):
	rate(500)
	r_A = A - sources[i].pos
	r_B = B - sources[i].pos

	VA  = VA + oofpez *sources[i].q/mag(r_A)
	VB  = VB + oofpez *sources[i].q/mag(r_B)

	i = i +1

print('The potential at A is {:1.3f} V'.format(VA))
print('The potential at B is {:1.3f} V'.format(VB))

print('The change of potential from B to A is {:1.3f} V'.format(VB-VA))

# Number of steps
Nsteps 		= 100
# Initial value for delta l
deltal 		= (B-A)/Nsteps
# Initializes the difference in potential
deltaV_AB 	= 0
# Starting position for the potential calculations
L       	= A
# Scale factor for the arrows
sf      	= 1e-7
# Initializes the index
k       	= 0
while k < Nsteps:
	rate(10)
# Initial value for the electric field
	Enet = vector(0, 0, 0)
	for i in range(N):
		r 		= L + deltal/2 - sources[i].pos
		Enet 	= Enet +  oofpez * sources[i].q/mag(r)**2 *norm(r)
# Update index
		i 		= i + 1

# Creates arrows in the direction of the electric field
	E_arrow 		= arrow()
	E_arrow.color 	= color.green
	E_arrow.pos 	= L + deltal/2
	E_arrow.axis 	= Enet * sf

# Creates arrows in the direction of delta l
	dl_arrow 		= arrow()
	dl_arrow.color 	= color.orange
	dl_arrow.pos    = L + deltal/2
	dl_arrow.axis   = deltal * 2

# Updates the Potential
	deltaV 		= -dot(Enet, deltal)
	deltaV_AB 	= deltaV_AB + deltaV
	L 			= L + deltal
# Updates index
	k 			= k + 1