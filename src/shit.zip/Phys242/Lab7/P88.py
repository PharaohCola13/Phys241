# Spencer Riley
from __future__ import division, print_function
from visual import *

scene = display(
	title="Problem 88",
	background=color.white)

scene.autoscale = True

oofpez  = 9e9  #[Nm^2/C^2]
s       = 0.01 # Separation [m]
qd      = 2e-9 # Charge [C]

# Positive Charge
s1          = sphere()
s1.pos      = vector(-s/2, 0, 0)
s1.radius   = 0.003
s1.color    = color.red
s1.q        = qd

# Negative Charge
s2          = sphere()
s2.pos      = vector(s/2, 0, 0)
s2.radius   = 0.003
s2.color    = color.blue
s2.q        = -qd

sources = [s1, s2]
# Start and End of path 1
A = vector(0.02, 0.02, 0)
B = vector(0.12, 0.08, 0)
path1 = [A,B]

# Start and End of path 2
C = vector(-0.03, -0.02, 0)
D = vector(-0.05, -0.07, 0)
path2 = [C,D]

# Creates the curves that follow the paths
curve(pos=path1, color=color.orange)
curve(pos=path2, color=color.green)

# Initial value for the potential [V]
VA = 0
VB = 0
VC = 0
VD = 0

# Initializes the index
i = 0
# Calculates the potential at the defined locations
while i < len(sources):
	rate(500)
	r_A = A - sources[i].pos
	r_B = B - sources[i].pos
	r_C = C - sources[i].pos
	r_D = D - sources[i].pos

	VA  = VA + oofpez *sources[i].q/mag(r_A)
	VB  = VB + oofpez *sources[i].q/mag(r_B)
	VC  = VC + oofpez *sources[i].q/mag(r_C)
	VD  = VD + oofpez *sources[i].q/mag(r_D)

	i = i +1

print('The potential at A is {:1.3f} V'.format(VA))
print('The potential at B is {:1.3f} V'.format(VB))
print('The potential at C is {:1.3f} V'.format(VC))
print('The potential at D is {:1.3f} V'.format(VD))

print('The change of potential from B to A is {:1.3f} V'.format(VB-VA))
print('The change of potential from C to D is {:1.3f} V'.format(VC-VD))