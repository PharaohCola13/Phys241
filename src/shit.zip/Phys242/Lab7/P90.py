# Spencer Riley
from __future__ import division, print_function
from visual import *

scene = display(
	title="Problem 90",
	background=color.white)
scene.autoscale 	= True

oofpez  = 9e9  		#[Nm^2/C^2]
# Total charge
Qtot    = -3e-8 	#[C]
# Number of charges
N       = 120
# Initialize the list that will contain the properties of the charge distribution
sources = []
# Used for the sphere placement
theta   = 0         # Initial Angle
dtheta  = (2*pi)/N  # Change of angle
R       = 0.04   	#Radius of the ring

#Creates the ring of charge
while theta < 2 * pi:
	rate(1000)
	a           = sphere()
	a.radius    = (pi * R)/N
	a.pos       = vector(R*cos(theta),R*sin(theta),0)
	a.color     = color.red
	a.q         = Qtot/N
	sources.append(a)
	theta 		= theta + dtheta

A = vector(0.02, 0, 0.02)
B = vector(0.12, 0, 0.08)

# Creates the path curve for the potential
path1 = [A,B]
curve(pos=path1, color=color.green)

# Initial value for the potential [V]
VA = 0
VB = 0

# Initializes the index
i = 0
# Calculates the potential at the defined locations
while i < len(sources):
	rate(500)
	r_A = A - sources[i].pos
	r_B = B - sources[i].pos

	VA  = VA + oofpez *sources[i].q/mag(r_A)
	VB  = VB + oofpez *sources[i].q/mag(r_B)

	i = i +1

print('The potential at A is {:1.3f} V'.format(VA))
print('The potential at B is {:1.3f} V'.format(VB))

print('The change of potential from B to A is {:1.3f} V'.format(VB-VA))
