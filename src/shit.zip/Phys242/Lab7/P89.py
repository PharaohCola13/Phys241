# Spencer Riley
from __future__ import division, print_function
from visual import *
scene = display(
	title="Problem 89",
	background=color.white)

scene.autoscale = True

oofpez  = 9e9  #[Nm^2/C^2]
# Total length of the rod of the charge
L       = 0.05 #[m]
# Total Charge
Qtot    = -2e-8 #[C]
# Number of spheres
N       = 50

# Used for the placement of the spheres
dx      = L/N   #[m/charge]
x0      = -L/2 + dx/2
# Initialize the list that will contain the properties of the charge distribution
sources = []
# Initializes index
i       = 0
# Creates the rod of charge with spheres
while i < N:
	a = sphere()
	a.pos = vector(0, x0+i*dx, 0)
	a.radius = dx
	a.color = color.red
	a.q     = Qtot/N

	sources.append(a)
	i = i + 1

# Path of potential
A = vector(0.02, 0.02, 0)
B = vector(0.12, 0.08, 0)

# Initial value for the potential
VA = 0
VB = 0


# Initializes the index
i = 0
# Calculates the potential at the defined locations
while i < len(sources):
	rate(500)
	r_A = A - sources[i].pos
	r_B = B - sources[i].pos

	VA  = VA + oofpez *sources[i].q/mag(r_A)
	VB  = VB + oofpez *sources[i].q/mag(r_B)

	i = i +1

print('The potential at A is {:1.3f} V'.format(VA))
print('The potential at B is {:1.3f} V'.format(VB))

print('The change of potential from B to A is {:1.3f} V'.format(VB-VA))
