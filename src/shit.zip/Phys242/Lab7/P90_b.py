# Spencer Riley
from __future__ import division, print_function
from visual import *

scene = display(
	title="Problem 90 Modified",
	background=color.white)
scene.forward = vector(1,0,0)
scene.width = scene.height = 500
scene.autoscale 	= True

oofpez  = 9e9  		#[Nm^2/C^2]
# Total charge
Qtot    = -3e-8 	#[C]
# Number of charges
N       = 120
# Initialize the list that will contain the properties of the charge distribution
sources = []
# Used for the sphere placement
theta   = 0         # Initial Angle
dtheta  = (2*pi)/N  # Change of angle
R       = 0.04   	#Radius of the ring

#Creates the ring of charge
while theta < 2 * pi:
	rate(1000)
	a           = sphere()
	a.radius    = (pi * R)/N
	a.pos       = vector(R*cos(theta),R*sin(theta),0)
	a.color     = color.red
	a.q         = Qtot/N
	sources.append(a)
	theta 		= theta + dtheta

A = vector(0.02, 0, 0.02)
B = vector(0.12, 0, 0.08)

# Creates the path curve for the potential
path1 = [A,B]
curve(pos=path1, color=color.green)

# Initial value for the potential [V]
VA = 0
VB = 0

# Initializes the index
i = 0
# Calculates the potential at the defined locations
while i < len(sources):
	rate(500)
	r_A = A - sources[i].pos
	r_B = B - sources[i].pos

	VA  = VA + oofpez *sources[i].q/mag(r_A)
	VB  = VB + oofpez *sources[i].q/mag(r_B)

	i = i +1

print('The potential at A is {:1.3f} V'.format(VA))
print('The potential at B is {:1.3f} V'.format(VB))

print('The change of potential from B to A is {:1.3f} V'.format(VB-VA))

# Number of steps
Nsteps 		= 100
# Initial value for delta l
deltal 		= (B-A)/Nsteps
# Initializes the difference in potential
deltaV_AB 	= 0
# Starting position for the potential calculation
L       	= A
# Scale factor for the arrows
sf      	= 1e-7
# Initializes the index
k       	= 0
while k < Nsteps:
	rate(10)
# Initial value for the electric field
	Enet = vector(0, 0, 0)
# Calculates the the sum of the Electric field over the components
	for i in range(N):
		r 		= L + deltal/2 - sources[i].pos
		Enet 	= Enet +  oofpez * sources[i].q/mag(r)**2 *norm(r)
# Updates the index
		i 		= i + 1

# Creates arrows in the direction of the electric field
	E_arrow 		= arrow()
	E_arrow.color 	= color.green
	E_arrow.pos 	= L + deltal/2
	E_arrow.axis 	= Enet * sf

# Creates arrows in the direction of delta l
	dl_arrow 		= arrow()
	dl_arrow.color 	= color.orange
	dl_arrow.pos    = L + deltal/2
	dl_arrow.axis   = deltal

# Updates the Potential
	deltaV 		= -dot(Enet, deltal)
	deltaV_AB 	= deltaV_AB + deltaV
	L 			= L + deltal
# Updates the index
	k 			= k + 1