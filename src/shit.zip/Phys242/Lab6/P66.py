# Spencer Riley
from __future__ import division, print_function
from visual import *

observation = []
slices      = []

oofpez  = 9e9   #[Nm^2/C^2]
yobs    = 0.4   #[m]
Qtot    = 1e-9  #[C]
R       = 0.15  #[m]

# A function that does all of the things
def calc(m, n, L):
	scene   = display()
	theta   = 0         # Initial Angle
	dtheta  = pi / 6    # Change of angle

	dy      = L/n       # Change in y for the position of the charges on the rod
	y0      = -L/2 + dy/2 # Initial y-position

	i       = 0         # Index
	af      = 0.0009    # Scale Factor
# Creates the "rod" of uniform charge
	while i < n:
		a           = sphere()
		a.pos       = vector(0, y0+i*dy, 0)
		a.radius    = dy/2
		a.color     = color.red
		a.q         = Qtot/n

		slices.append(a)
		i = i + 1
# Creates the arrows around the rod at five locations
	while theta < 2 * pi:
		k = 0
		while k < L:
			a       = arrow()
			a.pos   = vector(R * cos(theta), -(L)*yobs+k, R*sin(theta))
			a.color = color.orange
			a.axis  = vector(0,0,0)
			observation.append(a)
			k       = k + L/m
		theta       = theta + dtheta

	j = 0
# Calculates the Electric field at observation position
	while j < len(observation):
		rate(5e5)
		earrow  = observation[j]
		i       = 0     # Index
		E_net   = vector(0,0,0) #Inital Electric field
		while i < n:
			r       = earrow.pos - slices[i].pos
			rhat    = norm(r)
			E_net   = E_net + ((oofpez) * slices[i].q/mag(r)**2) * rhat
			i       = i + 1

		earrow.axis = af * E_net
		j = j + 1
	return E_net

l       = 1 # Length of rod, [m]
r       = vector(0, yobs, 0)
# Analytical Solution for the electric field
E_ana   = (oofpez) * (Qtot/(mag(r)*sqrt(mag(r)**2 + (l/2)**2))) * norm(r)

# Evaluates the function to get the Net Electric field for 10 and 16 charges
Ea = calc(5, 10, l)
Eb = calc(5, 16, l)

print("The difference between Part A and the Analytical solution {} N/C".format(E_ana-Ea))
print("The difference between Part B and the Analytical solution {} N/C".format(E_ana-Eb))