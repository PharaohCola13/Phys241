# Spencer Riley
from __future__ import division, print_function
from visual import *
from visual.graph import *

scene.height = 800
oofpez  = 9e9   #[Nm^2/C^2]
Qtot    = -2e-9 #[C]
L       = 0.5   #[m]
#N       = 10   #[number of charges]
#N       = 50    #[number of charges]
N       = 100  #[number of charges]
dx      = L/N   #[m/charge]
x0      = -L/2 + dx/2

r_obs   = vector(-0.4, 0.3, 0.3) # Observation Location [m]
E_net   = vector(0,0,0) # Initial Electric Field [N/C]
slices  = []

i       = 0
j       = 0
# Creates the uniform "rod" of charge
while i < N:
    rate(1000000000000)
    a = sphere()
    a.pos = vector(x0+i*dx, 0, 0)
    a.radius = dx/2
    a.color = color.red
    a.q     = Qtot/N

    slices.append(a)
    i = i + 1

# Calculates the electric field of each point on the rod
while j < N:
    rate(100)
    r       = r_obs - slices[j].pos
    rhat    = norm(r)
    E_net   = E_net + ((oofpez * slices[j].q/mag(r)**2) * rhat)
    j       = j + 1

# Produces an arrow representing the electric field at the observation point
scl             = 0.5 * L/mag(E_net) # A Dope Scale Factor
E_arrow         = arrow()
E_arrow.pos     = r_obs
E_arrow.axis    = scl* E_net
E_arrow.color   = color.green

# The analytical solution for the electric field of a uniformly distributed rod
E_analy = oofpez * Qtot/(mag(r_obs)*sqrt(mag(r_obs)**2+(L/2)**2)) * norm(r_obs)

print("The numerical electric field is {} N/C".format(E_net))
print("The analytical electric field is {} N/C".format(E_analy))
print("The difference between the solutions is {} N/C".format(E_net - E_analy))