# Spencer Riley
from __future__ import division, print_function
from visual import *

Qtot    = 50e-9 #[C]
oofpez  = 9e-9  #[Nm^2/C^2]

N       = 20    #[number of charges]
slices  = []
theta   = 0     # Initial Angle
dtheta  = (2*pi)/N  # Change of angle
R       = 0.1   #Radius of the ring

# The electron
electron        = sphere(make_trail=True)
electron.q      = -1.6e-19 #[C]
electron.m      = 9.11e-31 #[kg]
electron.radius = (pi * R)/N
# Initial Condition
electron.pos    = vector(0.15, 0, 0)
electron.p      = vector(0,0,0)
# Interesting Condition
#electron.pos    = vector(0.3, -0.05,0)
#electron.p      = electron.m * vector(1e-3, 1e-3, 1e-2)

#Creates the ring of charge
while theta < 2 * pi:
	rate(1000)
	a           = sphere()
	a.radius    = (pi * R)/N
	a.pos       = vector(0,R*cos(theta), R*sin(theta))
	a.color     = color.red
	a.q         = Qtot/N
	slices.append(a)
	theta = theta + dtheta

t       = 0 # Initial Time [s]
dt      = 6e-3 # Change in time [s]
# Calculates the electric field of the ring
while t < 1e3:
	E_net = vector(0, 0, 0)
	for i in range(N):
		rate(10000000000000)
		r        = electron.pos - slices[i].pos
		E_net    = E_net + ((oofpez * slices[i].q/(mag(r)**2)) * norm(r))
# Calculates the net force acting on the electron
	Fnet = E_net * electron.q
#Updates Momentum of electron
	electron.p = electron.p + Fnet * dt
# Updates Position of the electron
	electron.pos = electron.pos + (electron.p / electron.m) * dt
# Updates Time
	t = t + dt