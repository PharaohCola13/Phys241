# Spencer Riley
from __future__ import division, print_function
from visual import *

scene.background = color.white

# Scalar Factor
scale = 2e-7
# Given Charge
q1 = 3e-9 #[C]
# OOFPEZ
oofpez = 9e9 #[Nm^2/C^2]

# Charge 1
charge1         = sphere()
charge1.pos     = vector(-0.04, 0, 0)
charge1.radius  = 0.01
charge1.color   = color.red

### Part A
# Point of Evaluation
point1          = sphere()
point1.pos      = vector(-0.04,0, 0.05)
point1.radius   = 0.001
point1.color    = color.black
label(pos=point1.pos, text="{}".format(1), height=10)

### Part B
# Another Point of Evaluation
point2          = sphere()
point2.pos      = vector(-0.04, 0, -0.05)
point2.radius   = 0.001
point2.color    = color.black
label(pos=point2.pos, text="{}".format(2), height=10)

### Part C
# Another Point of Evaluation
point3          = sphere()
point3.pos      = vector(0,-0.05, 0)
point3.radius   = 0.001
point3.color    = color.black
label(pos=point3.pos, text="{}".format(3), height=10)

# Another Point of Evaluation
point4          = sphere()
point4.pos      = vector(0, 0.05, 0)
point4.radius   = 0.001
point4.color    = color.black
label(pos=point4.pos, text="{}".format(4), height=10)

### Part D
# Another Point of Evaluation
point5          = sphere()
point5.radius   = 0.001
point5.pos      = vector(-0.05, 0, 0)
point5.color    = color.black
label(pos=point5.pos, text="{}".format(5), height=10)

# Another other point of Evaluation
point6          = sphere()
point6.pos      = vector(0.05, 0, 0)
point6.radius   = 0.001
point6.color    = color.black
label(pos=point6.pos, text="{}".format(6), height=10)

# Distances for the points and the charge
### Part A
rA  = point1.pos - charge1.pos # [m]
### Part B
rB  = point2.pos - charge1.pos # [m]
### Part C
rC1 = point3.pos - charge1.pos # [m]
rC2 = point4.pos - charge1.pos # [m]
### Part D
rD1 = point5.pos - charge1.pos # [m]
rD2 = point6.pos - charge1.pos # [m]

# Electric Field function [N/C]
def E(a):
	E = oofpez * q1/mag(a)**2
	return E

# Electric Field at all of the eval points
### Part A
EA  = E(rA) #[N/C]
### Part B
EB  = E(rB) #[N/C]
### Part C
EC1 = E(rC1) #[N/C]
EC2 = E(rC2) #[N/C]
### Part D
ED1 = E(rD1) #[N/C]
ED2 = E(rD2) #[N/C]

# Creates an arrow for the electric field for each of the points
for i in [EA, EB, EC1, EC2, ED1, ED2]:
	for j in [rA, rB, rC1, rC2, rD1, rD2]:
		Efield = arrow()
		Efield.pos = charge1.pos
		Efield.axis = i * norm(j) * scale
		Efield.color = color.green