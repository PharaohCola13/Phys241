# Spencer Riley
from __future__ import division, print_function
from visual import *
from visual.graph import *

scene.width = scene.height = 800
scene.background = color.white
userzoom = True

graph1 	= gdisplay(title="Energy vs Time for Proton-Dipole Interactions", width=2000, height=600, ymax=5e-19, ymin=-5e-19, xmax=1e-13, xtitle="Time [s]", ytitle="Energy [J]", foreground=color.black, background=color.white)

kplot = gcurve(display= graph1, color=color.blue)
uplot = gcurve(display= graph1, color=color.red)

label(display=graph1.display, pos=(7.5e-14, 2e-19), color=color.blue, text="Kinetic Energy")
label(display=graph1.display, pos=(7.5e-14, 4e-19), color=color.red, text="Potential Energy")

oofpez  = 9e9 #[Nm^2/C^2]
qe      = 1.6e-19 #[C]
sf      = 5e-20

q_01    = qe # [C]
q_02    = -qe # [C]

def E_dipole(r, q):
	E = ((oofpez * q/mag(r)**2)) *norm(r)
	return E

# The Proton
proton 			= sphere()
proton.pos 		= vector(0.3e-9, 0, 0)
proton.radius 	= 0.5e-10 # [m]
proton.color 	= color.orange # [color]
proton.m 		= 1.67e-27 # [kg]
proton.p 		= vector(0, 0, 0)

# Positive part of the dipole
source_01 			= sphere()
source_01.pos 		= vector(0, 0.1e-9, 0)
source_01.radius 	= 0.5e-10
source_01.color 	= color.red

# Negative part of the dipole
source_02 			= sphere()
source_02.pos 		= vector(0, -0.1e-9, 0)
source_02.radius 	= 0.5e-10 # [m]
source_02.color 	= color.blue

def problem68():
# Initial value of theta
	theta    = 0
	while theta <= 2 * pi:
# 12 equally spaced points in the xy-plane
		points_ij         = sphere()
		points_ij.pos     = 0.5e-9 * vector(cos(theta), sin(theta), 0)
		points_ij.radius  = 0.1e-10
		points_ij.color   = color.black

# 12 equally spaced points in the yz-plane
		points_jk         = sphere()
		points_jk.pos     = 0.5e-9 * vector(0, cos(theta), sin(theta))
		points_jk.radius  = 0.1e-10
		points_jk.color   = color.black

# Distances with respect to the source charges and the points in the xy-plane
		r1_ij = points_ij.pos - source_01.pos
		r2_ij = points_ij.pos - source_02.pos

# Distances with respect to the source charges and the points in the yz-plane
		r1_jk = points_jk.pos - source_01.pos
		r2_jk = points_jk.pos - source_02.pos

# Electric field for the xy-plane points
		E_pos_ij = E_dipole(r1_ij, qe)
		E_neg_ij = E_dipole(r2_ij, -qe)
		E_net_ij = E_pos_ij + E_neg_ij

# Electric field for the yz-plane points
		E_pos_jk = E_dipole(r1_jk, qe)
		E_neg_jk = E_dipole(r2_jk, -qe)
		E_net_jk = E_pos_jk + E_neg_jk

# E-Field arrows for the xy-plane points
		Efield_ij = arrow()
		Efield_ij.pos = points_ij.pos
		Efield_ij.axis = sf*E_neg_ij
		Efield_ij.color = color.green

# E-Field arrows for the yz-plane points
		Efield_jk = arrow()
		Efield_jk.pos = points_jk.pos
		Efield_jk.axis = sf*E_neg_jk
		Efield_jk.color = color.green

		theta = theta + pi/6

def partab():
# Initial Time
	t = 0 # [s]
# Time step
	dt = 1e-17  # [s]

	while t <= 1e-13:
		rate(1000)
# Distance of the proton with respect to both parts of the dipole
		r1  = proton.pos - source_01.pos
		r2  = proton.pos - source_02.pos

# Calculations for Electric field with respect to the proton
		E_pos   = E_dipole(r1, qe)
		E_neg   = E_dipole(r2, -qe)
		E_net   = E_pos + E_neg

# Force calculation
		F_net = (qe) * (E_net)
# Updates proton momentum
		proton.p = proton.p + F_net * dt
# Updates proton position
		proton.pos = proton.pos + (proton.p/proton.m) *dt

# Kinetic Energy of the proton
		K = 0.5 * mag(proton.p)**2/proton.m
# Potential energy of the system (proton interactions with dipole)
		U = oofpez * (qe)**2/mag(r1) + oofpez * -qe**2/mag(r2)

# Kinetic Energy Plot
		kplot.plot(pos=(t, K))
# Potential Energy Plot
		uplot.plot(pos=(t,U))
# Updates Time
		t = t + dt

# Runs the function
problem68()
# Runs the other function
partab()