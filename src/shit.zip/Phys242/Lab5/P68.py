# Spencer Riley
from __future__ import division, print_function
from visual import *

scene.width = scene.height = 800
scene.background = color.white

# OOFPEZ
oofpez  = 9e9 #[Nm^2/C^2]
# Fundamental Charge
qe      = 1.6e-19 #[C]
# Scale Factor
sf      = 5e-20
# Charge of source_01
q_01    = qe
# Charge of source_02
q_02    = -qe

# Electric Field Function
def E_dipole(r, q):
	E = ((oofpez * q/mag(r)**2)) *norm(r)
	return E

# Positive part of the dipole
source_01           = sphere()
source_01.pos       = vector(0, 0.1e-9, 0)
source_01.radius    = 0.5e-10 #[m]
source_01.color     = color.red

# Negative part of the dipole
source_02           = sphere()
source_02.pos       = vector(0, -0.1e-9, 0)
source_02.radius    = 0.5e-10 #[m]
source_02.color     = color.blue

###  Part A
def parta():
# Initial Theta
	theta    = 0
	while theta <= 2 * pi:
# Gets the 12 equally spaced points around the dipole
		points         = sphere()
		points.pos     = 0.5e-9 * vector(cos(theta), sin(theta), 0)
		points.radius  = 0.1e-10
		points.color   = color.black

# Finds the distance between the points with respect to both halfs of the dipole
		r1 = points.pos - source_01.pos
		r2 = points.pos - source_02.pos

# Finds the Electric Field with respect to both parts of the dipole
		E_pos = E_dipole(r1, qe)
		E_neg = E_dipole(r2, -qe)
# Net Electric Field
		E_net = E_pos + E_neg

# Puts an arrow describing electric field for all of the points
		Efield          = arrow()
		Efield.pos      = points.pos
		Efield.axis     = sf*E_net
		Efield.color    = color.green
# Updates theta
		theta = theta + pi/6

### Part B
# The same thing as above, expect for a different cross section of the field
def partb():
	theta    = 0
	while theta <= 2 * pi:
		points         = sphere()
		points.pos     = 0.5e-9 * vector(0, cos(theta), sin(theta))
		points.radius  = 0.1e-10
		points.color   = color.black

		r1 = points.pos - source_01.pos
		r2 = points.pos - source_02.pos

		E_pos = E_dipole(r1, qe)
		E_neg = E_dipole(r2, -qe)
		E_net = E_pos + E_neg

		Efield          = arrow()
		Efield.pos      = points.pos
		Efield.axis     = sf*E_net
		Efield.color    = color.magenta

		theta = theta + pi/6

# Runs the function
parta()
# Runs the other function
partb()