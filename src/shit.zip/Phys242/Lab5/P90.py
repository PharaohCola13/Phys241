# Spencer Riley
from __future__ import division, print_function
from visual import *
from visual.graph import *

scene.background = color.white
userzoom = True

gdx1 = gdisplay(title="Part A: Angle vs Time", width=1600, height=500, xtitle="Time [s]", ytitle="Angle [rads]",
			   background=color.white, foreground=color.black)
gdx2a = gdisplay(title="Part B1: Angle vs Time", width=1600, height=500, xtitle="Time [s]", ytitle="Angle [rads]",
			   background=color.white, foreground=color.black)
gdx2b = gdisplay(title="Part B2: Angle vs Time", width=1600, height=500, xtitle="Time [s]", ytitle="Angle [rads]",
			   background=color.white, foreground=color.black)
gdx3 = gdisplay(title="Part C: Angle vs Time", width=1600, height=500, xtitle="Time [s]", ytitle="Angle [rads]",
			   background=color.white, foreground=color.black)
gdx4 = gdisplay(title="Part D: Angle vs Time", width=1600, height=500, xtitle="Time [s]", ytitle="Angle [rads]",
			   background=color.white, foreground=color.black)

AngleA = gcurve(gdisplay=gdx1)
AngleB1 = gcurve(gdisplay=gdx2a)
AngleB2 = gcurve(gdisplay=gdx2b)
AngleC = gcurve(gdisplay=gdx3)
AngleD = gcurve(gdisplay=gdx4)


def E_field(r, q):
	E = ((oofpez * q/mag(r)**2)) *norm(r)
	return E

mass 	= 1e-6 #[kg]
q    	= 2e-10 #[C]
R    	= 1e-3 # [m]
oofpez 	= 9e9 #[Nm^2/C^2]
I       = 2 * mass * R**2 # [kg m^2]
rcm 	= vector(0.02, 0, 0) # [m]

# Postive part of the dipole
dipole_p         = sphere()
dipole_p.pos     = vector(0.02, 0, 0) + vector(R * cos(pi/6), R * sin(pi/6), 0)
dipole_p.color   = color.red
dipole_p.radius  = 2e-3

# Negative part of the dipole
dipole_n         = sphere()
dipole_n.pos     = vector(0.02, 0, 0) - vector(R * cos(pi/6), R * sin(pi/6), 0)
dipole_n.color   = color.blue
dipole_n.radius  = 2e-3

# That random charge thats just doin random charge things
charge          = sphere()
charge.pos      = vector(-0.02, 0, 0)
charge.color    = color.red
charge.radius   = 2e-3

# Initial Time
t   		= 0 # [s]
# Time Step
dt  		= 1e-3 # [s]

# Initial Angular Momentum
L   		= vector(0,0,0) # [kg m^2/s]

## Angles
### Part A
theta 	= pi/6 # [rads]
### Part B
thetab1 = 0.01 * pi # [rads]
thetab2 = 0.02 * pi # [rads]
### Part C
thetac 	= pi/2 # [rads]
### Part D
thetad 	= pi/6 # [rads]

# Axis of Rotation
aor 	= rcm + vector(0, 0, 1)

while t <= 1:
	rate(100)
## Positive part of the dipole
# Distance from the charge
	r_pos 			= dipole_p.pos - charge.pos
# Force acting on the dipole
	F_pos 			= E_field(r_pos, q) * q
### Part D
#	F_pos 			= E_field(r_pos, q) * 4 * q

## Negative part of the dipole
# Distance from the charge
	r_neg 			= dipole_n.pos - charge.pos
# Force acting on the dipole
	F_neg 			= E_field(r_neg, -q) * q
### Part D
#	F_neg			= E_field(r_neg, -q) * 4 * q

# Calculates Torque for both parts of the dipole
	torque_pos 		= cross(dipole_p.pos - rcm, F_pos)
	torque_neg 		= cross(dipole_n.pos - rcm, F_neg)
	torque_net 		= torque_pos + torque_neg

# Updates Angular Momentum
	L 				= L + torque_net * dt
	omega 			= L/I

	omega_scalar 	= dot(omega, norm(aor))
	dtheta 			= omega_scalar * dt

# Rotates the components of the dipole
	dipole_p.rotate(angle=dtheta, axis=aor, origin=rcm)
	dipole_n.rotate(angle=dtheta, axis=aor, origin=rcm)

## Plots theta against time
### Part A
	AngleA.plot(pos=(t, theta), color=color.magenta)
### Part B
	AngleB1.plot(pos=(t, thetab1), color=color.red)
	AngleB2.plot(pos=(t, thetab2), color=color.blue)
### Part C
	AngleC.plot(pos=(t, thetac), color=color.green)
### Part D
	AngleD.plot(pos=(t, thetad), color=color.orange)


## Updates Theta
### Part A
	theta 	= theta + dtheta
### Part B
	thetab1 = thetab1 + dtheta
	thetab2 = thetab2 + dtheta
### Part C
	thetac 	= thetac + dtheta
### Part D
	thetad 	= thetad + dtheta

# Updates Time
	t 		= t + dt

# Part A: Period ~0.4
# Part B1: Period ~0.4
# Part B2: Period ~0.4
# Part C: Period ~0.4
# Part D: Ratio between Period D and Period B1 ~ 1/2
# Part D: Ratio between Period D and Period B2 ~ 1/2