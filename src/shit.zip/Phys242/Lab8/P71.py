# Spencer Riley
from __future__ import division, print_function
from visual import *
from visual.graph import *

# Creates the graphical display for position
gd1 = gdisplay(x=550,y=0,width=1000,height=700,
			   title='Correlation between Electric Field and Distance',
			   xtitle='Distance [m]',
			   ytitle='Electric Field [N/C]',
			   background=color.white,
			   foreground=color.black)
label(display=gd1.display,
	  pos=(5.0e-10,5e10),
	  text="Superposition",
	  color=color.red,)
label(display=gd1.display,
	  pos=(5e-10,2.5e10),
	  text="Analytic",
	  color=color.blue)
scene.width = scene.height = 800
scene.background = color.white

# OOFPEZ
oofpez  = 9e9 #[Nm^2/C^2]
# Fundamental Charge
qe      = 1.6e-19 #[C]
# Scale Factor
sf      = 5e-20
# Charge of source_01
q_01    = qe
# Charge of source_02
q_02    = -qe
# Electric Field Function
def E_Field(r, q):
	E = ((oofpez * q/mag(r)**2)) *norm(r)
	return E

# Positive part of the dipole
source_01           = sphere()
source_01.pos       = vector(0, 0.1e-9, 0)
source_01.radius    = 0.5e-10 #[m]
source_01.color     = color.red

# Negative part of the dipole
source_02           = sphere()
source_02.pos       = vector(0, -0.1e-9, 0)
source_02.radius    = 0.5e-10 #[m]
source_02.color     = color.blue

# An array defining the observation points from 0.2 nm to 0.5 nm
r 	= linspace(0.2e-9, 0.5e-9, 100)

f1 	= gcurve(gdisplay=gd1)  # Define functions to plot
f2 	= gcurve(gdisplay=gd1)  # Define functions to plot

def parta():
# Calculates the Electric field for each observation point defined by the array r
	for i in r:
		r_1 	= vector(0,i,0) - source_01.pos
		r_2 	= vector(0,i,0) - source_02.pos
		E_pos 	= E_Field(r_1, q_01)
		E_neg 	= E_Field(r_2, q_02)
		E 		= E_pos + E_neg
# Plots the y-direction of the E-field against the distance from the center
		f1.plot(pos=(i,E.y), color=color.red)  # Plots position vs Electric Field
	print("The Superposition Solution for the Electric Field is {:1.3E} N/C".format(E.y))
	return E.y

def partb():
	for j in r:
		s 	= mag(source_01.pos - source_02.pos)
		E 	= oofpez * (2 * q_01 * s)/(j**3)
# Plots the y-direction of the E-field against the distance from the center
		f2.plot(pos=(j, E), color=color.blue)  # Plots position vs Electric Field
	print("The Analytical Solution for the Electric Field is {:1.3E} N/C".format(E))
	return E

# Runs parta
parta()
# Runs partb
partb()