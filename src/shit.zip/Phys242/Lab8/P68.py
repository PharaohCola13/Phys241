# Spencer Riley
from __future__ import division, print_function
from visual import *

scene.width = scene.height = 800
scene.background = color.white

# OOFPEZ
oofpez  = 9e9 #[Nm^2/C^2]
# Total charge distributed on each rod
Qtot    = 3e-9 #[C]
# Length of each rod
L       = 0.4 #[m]
# Number of spheres
N       = 20
# Used for the placement of the spheres
dx      = L/N   #[m/charge]
x0      = -L/2 + dx/2
# Initialize the list that will contain the properties of the charge distribution
sources = []
# Initializes index
i       = 0
# Creates the square of charge with spheres
while i < N:
	a           = sphere()
	a.pos       = vector(0, x0+i*dx, L/2)
	a.radius    = dx
	a.color     = color.red
	a.q         = Qtot/N
	sources.append(a)

	b           = sphere()
	b.pos       = vector(0,x0+i*dx, -L/2)
	b.radius    = dx
	b.color     = color.red
	b.q         = Qtot/N
	sources.append(b)

	c           = sphere()
	c.pos       = vector(0,L/2, x0 + i * dx)
	c.radius    = dx
	c.color     = color.red
	c.q         = Qtot/N
	sources.append(c)

	d           = sphere()
	d.pos       = vector(0, -L/2, x0+i*dx)
	d.radius    = dx
	d.color     = color.red
	d.q         = Qtot/N
	sources.append(d)

	i = i + 1
# Number of Steps
Nsteps  = 10
# Scale factor for the arrow
sf      = 1e-4
# Initializes the index
k       = 0
while k < Nsteps:
	rate(10)
	leftE 	= []
	rightE 	= []
	for j in linspace(0, L, 6):
# Initial value for the electric field
		Enet1 = vector(0, 0, 0)
		Enet2 = vector(0, 0, 0)
# Observation positions along the x=+-0.1 line
		R_obs1 = vector(0.1, j, 0)
		R_obs2 = vector(-0.1, -j, 0)
# Calculates the the sum of the Electric field over the components
		for i in range(len(sources)):
			r1 = R_obs1 - sources[i].pos
			r2 = R_obs2 - sources[i].pos
			Enet1 = Enet1 + oofpez * sources[i].q/mag(r1)**2 * norm(r1)
			Enet2 = Enet2 + oofpez * sources[i].q/mag(r2)**2 * norm(r2)
# Creates arrows in the direction of the electric field
		E_arrow1        = arrow()
		E_arrow1.color  = color.green
		E_arrow1.pos    = R_obs1
		E_arrow1.axis   = Enet1 * sf
		leftE.append(Enet1)
# Creates arrows in the direction of the electric field
		E_arrow2        = arrow()
		E_arrow2.color  = color.green
		E_arrow2.pos    = R_obs2
		E_arrow2.axis   = Enet2 * sf
		rightE.append(Enet2)
	k = k + 1

print("---"*5 + " x=0.1 " + "---"*5)
for i in range(len(leftE)):
	print("{}".format(leftE[i]) + " N/C")

print("---"*5 + " x=-0.1 " + "---"*5)
for i in range(len(rightE)):
	print("{}".format(rightE[i]) + " N/C")