# Spencer Riley
from __future__ import division, print_function
from visual import *

scene = display(background=color.white)
scene.forward 		= vector(1,0,0)
scene.width 		= scene.height = 500
scene.autoscale 	= True
scene.autocenter	= True

oofpez  = 9e9  		#[Nm^2/C^2]
# Total charge
Qtot    = 4e-8 	#[C]
# Number of charges
N       = 1000
# Initialize the list that will contain the properties of the charge distribution
sources = []
R       = 0.001  	# Radius of the ring [m]
#Creates the cylinder (rod) of charge
for i in linspace(-0.15, 0.15, N):
	rate(100000)
	a = sphere()
	a.radius 	= R
	a.pos		= vector(i, 0, 0)
	a.color 	= color.red
	a.q			= Qtot/N
	sources.append(a)

# Initial and Final position of the curve
A = vector(0, 0.05, 0)
B = vector(0.15, 0.05, 0)
# Creates the path curve for the potential
path1 = [A,B]
curve(pos=path1, color=color.green)

# Initial value for the potential [V]
VA = 0
VB = 0

# Initializes the index
i = 0
# Calculates the potential at the defined locations
while i < len(sources):
	r_A = A - sources[i].pos
	r_B = B - sources[i].pos

	VA  = VA + oofpez *sources[i].q/mag(r_A)
	VB  = VB + oofpez *sources[i].q/mag(r_B)

	i = i +1

print('The potential at A is {:1.3f} V'.format(VA))
print('The potential at B is {:1.3f} V'.format(VB))

print('The change of potential from B to A is {:1.3f} V'.format(VB-VA))

# Number of steps
Nsteps 		= 100
# Initial value for delta l
deltal 		= (B-A)/Nsteps
# Initializes the difference in potential
deltaV_AB 	= 0
# Starting position for the potential calculation
L       	= A
# Scale factor for the arrows
sf      	= 5e-7
# Initializes the index
k       	= 0
while k < Nsteps:#
	rate(1000)
# Initial value for the electric field
	Enet = vector(0, 0, 0)
# Calculates the the sum of the Electric field over the components
 	for i in range(len(sources)):
 		r 		= L + deltal/2 - sources[i].pos
 		Enet 	= Enet +  oofpez * sources[i].q/mag(r)**2 *norm(r)
# # Updates the index
 		i 		= i + 1

# Creates arrows in the direction of the electric field
 	E_arrow 		= arrow()
 	E_arrow.color 	= color.green
 	E_arrow.pos 	= L + deltal/2
 	E_arrow.axis 	= Enet * sf
#
# # Creates arrows in the direction of delta l
 	dl_arrow 		= arrow()
 	dl_arrow.color 	= color.orange
 	dl_arrow.pos    = L + deltal/2
 	dl_arrow.axis   = deltal * 10
#
# # Updates the Potential
 	deltaV 		= -dot(Enet, deltal)
 	deltaV_AB 	= deltaV_AB + deltaV
 	L 			= L + deltal
# # Updates the index
 	k 			= k + 1