# Spencer Riley
from __future__ import division, print_function
from visual import *

scene.width = scene.height = 800
scene.background = color.white
## Constants ##
mzofp   = 1e-7 # Magnetic Permeability over 4pi
B0      = vector(0,0.2,0) # Initial Magnetic field
bscale  = 1 # Scale for the magnetic field arrows

# Used to make the floor grid
def floor_grid():
	xmax    = 0.4
	dx      = 0.1
	yg      = -0.1
	x       = -xmax
	while x < xmax+dx:
		curve(pos=[(x, yg, -xmax), (x, yg, xmax)], color=(0.7, 0.7, 0.7))
		x = x + dx
	z   = -xmax
	while z < xmax + dx:
		curve(pos=[(-xmax, yg, z), (xmax, yg, z)], color=(0.7,0.7,0.7))
		z   = z +dx
	x = -xmax
	dx = 0.2
	while x < xmax+dx:
		z = -xmax
		while z < xmax+dx:
			arrow(pos=(x,yg,z),axis=B0 * bscale, color=(0, 0.8, 0.8))
			z = z + dx
		x = x + dx
floor_grid()
# Creates the particle
particle        = sphere(make_trail=True)
particle.pos    = vector(0,0.15, 0)
particle.radius = 1e-2
particle.color  = color.yellow
particle.q      = -1.6e-19
particle.m      = 1.7e-27
# Initial velocity
#particle.v      = vector(-2e6, 1e6,0)
particle.v      = vector(-2e6, 0, 0)
#particle.v      = vector(-2e6/2, 0, 0)
#particle.v      = vector(-2e6*2, 0, 0)
# Initial momentum
particle.p      = particle.m * particle.v

# Initial Time
t = 0
# Change in time
dt = 5e-11
while t < 3.34e-7:
	rate(1000)
# Calculates the velocity
	particle.v      = particle.p/particle.m
# Calculates the net force
	Fnet            = particle.q * cross(particle.v, B0)
# Updates the particle's momentum
	particle.p      = particle.p + Fnet * dt
# Updates the particle's position
	particle.pos    = particle.pos + particle.v * dt
# Updates time
	t = t + dt
	# Calculates the radius via analytical methods
R_analy = mag(particle.p) / (abs(particle.q) * mag(B0))
print("The radius of the circular path is {:1.3f} m".format(R_analy))