# Spencer Riley
from __future__ import division, print_function
from visual import *

scene.width = scene.height = 800
scene.background = color.white
# Magnetic Permeability over 4pi
mzofp 	= 1e-7
I1 	    = 5     # Current of wire [A]
I2      = 2     # Current of loop [A]

# Height of the loop
H       = 0.3 #[m]
# Width of the loop
W       = 0.5 #[m]

# Used to position the sides of the square
x0  = (W/2)
y0  = (H/2)
# Creates a box out of smaller, thinner boxes
def square_loop():
	square 		= []
	sqr_l	    = box()
	sqr_l.pos   = vector(-x0, 0, 0)
	sqr_l.axis  = vector(0, y0*2, 0)
	sqr_l.p 	= vector(0, 0, 0)
	sqr_l.m 	= 1

	sqr_r	    = box()
	sqr_r.pos   = vector(x0, 0, 0)
	sqr_r.axis  = vector(0, y0*2, 0)
	sqr_r.p 	= vector(0, 0, 0)
	sqr_r.m 	= 1

	sqr_t	    = box()
	sqr_t.pos   = vector(0, y0, 0)
	sqr_t.axis  = vector(x0*2, 0, 0)
	sqr_t.p 	= vector(0, 0, 0)
	sqr_t.m 	= 1

	sqr_b	    = box()
	sqr_b.pos   = vector(0, -y0, 0)
	sqr_b.axis  = vector(x0*2, 0, 0)
	sqr_b.p 	= vector(0, 0, 0)
	sqr_b.m 	= 1

	sqr_b.width = sqr_b.height 	= \
		sqr_l.width = sqr_l.height =\
		sqr_t.width = sqr_t.height = \
		sqr_r.width = sqr_r.height = 0.02

	sqr_b.color = sqr_t.color = \
		sqr_l.color = sqr_r.color = color.red

	square.append(sqr_l)
	square.append(sqr_r)
	square.append(sqr_t)
	square.append(sqr_b)
	return square
square = square_loop()

d           = 0.25  # Distance between rod and loop
L           = 2.5	# Length of Wire

# Creates a wire
wire        = box()
wire.pos    = vector(-d-x0, 0, 0)
wire.axis   = vector(0, L, 0)
wire.width  = wire.height = 0.02
wire.color  = color.green

# Observation locations
obs = [vector(-x0, 0, 0),vector(x0, 0, 0),
	   vector(0, y0, 0),vector(0, -y0, 0)]

# Scale factor for magnetic force arrows
sf      = 1e4
# Initializes list for Fnet Calculation
force   = []
# Initializes list to update arrows
field   = []
# Initializes the Magnetic force Arrows
for i in range(len(obs)):
	bdot         = arrow()
	bdot.pos     = obs[i]
	bdot.color   = color.magenta
	field.append(bdot)

# Calculates the Net Force
def net_force():
    force = []
    for j in range(len(square)):
        robs    = wire.pos - square[j].pos
        B       = mzofp * ((2 * I2 * I1) * (mag(obs[j]) * 2)) / mag(robs)
        F       = I2 * B * L * norm(obs[j])
        field[j].axis = F * sf
        force.append(F)
    Fnet = force[0] + force[1] + force[2] + force[3]
    return Fnet

# Initial Time
t = 0
# Time Step
dt = 1e-2
# Moves the box in the direction of the force
while t < 16000 * dt:
	rate(1e10)
	for j in range(len(square)):
# Defines the Net force
		Fnet = net_force()
# Updates the momentum
		square[j].p    = square[j].p + Fnet * dt
# Updates the position
		square[j].pos  = square[j].pos + (square[j].p/square[j].m) * dt
# Updates the arrow position
		field[j].pos = square[j].pos
	t = t +dt