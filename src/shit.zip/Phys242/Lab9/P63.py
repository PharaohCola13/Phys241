# Spencer Riley
from __future__ import division, print_function
from visual import *

scene.width = scene.height = 800
scene.background = color.white

# Magnetic Permeability over 4pi
mzofp 	= 1e-7
# Current
I 	= 3 #[A]
# Integers used for number of points
n = 4
N  = 10 * n
# Length
L  = 0.1 #[m]
# Used to position the sides of the square
dx = L/N
x0 = -L/2 + dx/2
# Radius of the curve objects
R  = 0.01
# Creates the square of charge with spheres
a 			= curve()
a.radius 	= R
a.color 	= color.red
a.retain 	= N

b 			= curve()
b.radius 	= R
b.color		= color.red
b.retain	= N

c 			= curve()
c.radius 	= R
c.color		= color.red
c.retain	= N

d 			= curve()
d.radius	= R
d.color		= color.red
d.retain	= N
# Initializes the index
i  = 0
# Adds side position to curve object
while i < N:
	a.append(pos=vector(0, x0+i*dx, L/2))
	i = i + 1
# Re-initializes the index
i = 0
# Adds side position to curve object
while i < N:
	b.append(pos=vector(0,L/2, x0 + i * dx))
	i = i + 1
# Re-initializes the index
i = 0
# Adds side position to curve object
while i < N:
	c.append(pos=vector(0,x0+i*dx, -L/2))
	i = 1 + i
# Re-initializes the index
i = 0
# Adds side position to curve object
while i < N:
	d.append(pos=vector(0, -L/2, x0+i*dx))
	i = i + 1

## Adds positions from all sides of the square to one list
wire = []
for i in range(len(a.pos)):
	wire.append(a.pos[i])
	wire.append(b.pos[i])
	wire.append(c.pos[i])
	wire.append(d.pos[i])

##Creates arrows representing magnetic field in the x-y plane
obs 	= []
theta 	= 0.
dtheta  = (2 *pi)/20
while theta < 2*pi:
	bdot 		= arrow()
	bdot.pos 	= vector(cos(theta),sin(theta),0)
	bdot.color 	= color.cyan
	theta 		= theta + dtheta
	obs.append(bdot)

# Initializes the index
iobs = 0
# Defines the number of steps
Nsteps = 39 * n
# Scale factor for magnetic field arrows
sf = 5e6
while iobs < len(obs):
# Initializes the magnetic field
	B = vector(0,0,0)
# Initializes the index
	i = 0
# Calculates the magnetic field at the observation positions
	while i < Nsteps:
		rate(1000)
		dl 	 = wire[i+1] - wire[i]
		loc  = wire[i] + dl/2
		robs = obs[iobs].pos - loc
		rhat = norm(robs)
		rmag = mag(robs)
		B 	 = B + mzofp * (I * cross(dl, rhat)) / rmag ** 2
		i 	 = i + 1
# Prints the numerical/analytical solution of the magnetic field along the axis
	if robs.x**2 == 1:
		print(robs)
		print("Numerical Solution {}:\t {:1.3E} T".format(iobs,mag(B)))
		B_analy = 2 * mzofp * ((I*L) / (mag(robs) * sqrt(mag(robs) ** 2 + (L / 2) ** 2)))
		print("Analytical Solution {}:\t {:1.3E} T".format(iobs, B_analy))
# Prints the numerical/analytical solution of the magnetic field parallel to the square
	if 1 - robs.y**2 < 0.01:
		print(robs)
		print("Numerical Solution {}:\t {:1.3E} T".format(iobs,mag(B)))
		B_analy = 2 * mzofp * ((I*L) / (mag(robs) * sqrt(mag(robs) ** 2 + (L / 2) ** 2)))
		print("Analytical Solution {}:\t {:1.3E} T".format(iobs, B_analy))
# Updates the magnetic field arrows
	obs[iobs].axis = sf * B
	iobs = iobs + 1