# Spencer Riley
from __future__ import division, print_function
from visual import *

scene.width = scene.height = 800
scene.background = color.white

# Magnetic Permeability over 4pi
mzofp 	= 1e-7
# Scale Factor
sf = 1e-8

## Proton/Anti-Proton
proton          = sphere()
proton.pos      = vector(-4e-10, 0, 0)
proton.radius   = 1e-10
proton.color    = color.red
proton.m        = 1.6e-27
proton.v        = vector(8e4,0,0)
proton.q        = 1.6e-19
# Charge for a Anti-Proton
#proton.q        = -1.6e-19

## Initializes Four arrows representing the magnetic field
r 		= []
theta 	= 0
dtheta 	= 2*pi/4
while theta < 2 * pi:
	bfield 			= arrow()
	bfield.color 	= color.cyan
	bfield.pos 		= vector(0, 8e-11 * sin(theta), 8e-11 * cos(theta))
	r.append(bfield)

	bfield 			= arrow()
	bfield.color 	= color.cyan
	bfield.pos 		= vector(-2e-10, 8e-11 * sin(theta), 8e-11 * cos(theta))
	r.append(bfield)

	bfield 			= arrow()
	bfield.color 	= color.cyan
	bfield.pos 		= vector(2e-10, 8e-11 * sin(theta), 8e-11 * cos(theta))
	r.append(bfield)
	theta 			= theta + dtheta
# Initial Time
t 	= 0 #[s]
# Change in time
dt 	= 1e-16 #[s]
while t < 100 * dt:
	rate(10)
# Updates the position of the proton
	proton.pos = proton.pos + proton.v * dt
# Initializes the index
	j = 0
# Calculates the magnetic field and updates the arrow
	while j < len(r):
		robs 	=  r[j].pos - proton.pos
		rhat 	= norm(robs)
		rmag 	= mag(robs)
		B 		= mzofp * (proton.q * cross(proton.v, rhat)) / rmag ** 2
# Updates the magnetic field arrows
		r[j].axis = B * sf
		j = j + 1
	t = t +dt