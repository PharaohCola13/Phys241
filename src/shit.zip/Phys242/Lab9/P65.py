# Spencer Riley
from __future__ import division, print_function
from visual import *

scene.width = scene.height = 800
scene.background = color.white

mzofp 	= 1e-7 # Magnetic Permeability over 4pi
L 		= 0.5 # Length of Solenoid
R 		= 0.03 # Radius of Solenoid

I 		= 1 # Conventional Current
Nturns 	= 75 # Number of turns
Nsteps 	= 20 # Number of line segments/turns

## Initializes the solenoid curve
solenoid        = curve()
solenoid.color  = color.yellow
solenoid.radius = 0.001

## Used to calculate the positions for the solenoid
dx 		= L/(Nturns * Nsteps)
omega 	= 2*pi*Nturns/L
x 		= -L/2

## Creates the positions of the solenoid
while x < L/2 + dx:
	solenoid.append(pos=vector(x, R*sin(x*omega), R*cos(x*omega)))
	x = x + dx

## This whole thing initializes the arrows for the magnetic field inside and outside of the solenoid
obs 	= []
dx 		= L/4
ylist 	= [-0.05, -0.04, -0.02, -0.01, 0, 0.01, 0.02, 0.04, 0.05]

x = -L/2
while x < L/2 + dx:
	i = 0
	B = vector(0,0,0)
	while i < len(ylist):
		aa = arrow()
		aa.pos=vector(x, ylist[i], 0)
		aa.axis = vector(0,0,0.05)
		aa.color = color.cyan
		aa.shaftwidth = 0.003
		obs.append(aa)
		i = i + 1
	x = x + dx

# Initializes the index
iobs = 0
# Scale Factor
sf = 3e2
while iobs < len(obs):
# Initializes the magnetic field
	B = vector(0,0,0)
# Initializes the index
	i = 0
# Calculates the magnetic field
	while i < Nsteps * Nturns:
		rate(1e5)
		dl 	 = solenoid.pos[i+1] - solenoid.pos[i]
		loc  = solenoid.pos[i] + dl/2
		robs = obs[iobs].pos - loc
		rhat = norm(robs)
		rmag = mag(robs)
		B 	 = B + mzofp * (I * cross(dl, rhat)) / rmag ** 2
		i 	 = i + 1

# Prints out the numerical/analytical solution for the center of the solenoid
	if obs[iobs].pos == vector(0,0,0):
		print("Numerical Solution ({}): {:1.2E}".format(iobs,mag(B)))
		B_analy = (mzofp*4*pi) * (Nturns * I)/(L)
		print("Analytical Solution ({}): {:1.2E}".format(iobs,B_analy))
# Updates the magnetic field arrow
	obs[iobs].axis = sf * B
	iobs = iobs + 1