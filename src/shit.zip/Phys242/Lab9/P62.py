# Spencer Riley
from __future__ import division, print_function
from visual import *

scene.width = scene.height = 800
scene.background = color.white

mzofp 	= 1e-7 # Magnetic Permeability over 4pi
# Scale Factor for magnetic field
sf = 1e-8
# Scale factor for electric field
sf2 = 1e-20
# OOFPEZ
oofpez = 9e9

## Creates Proton/Anti-Proton
proton          = sphere()
proton.pos      = vector(-4e-10, 0, 0)
proton.radius   = 1e-10
proton.color    = color.red
proton.m        = 1.6e-27
proton.v        = vector(8e4,0,0)
proton.q        = 1.6e-19
# Charge for anti-proton
#proton.q        = -1.6e-19

## Initializes the arrows for the magnetic field
r   = []
theta = 0
dtheta = 2*pi/4
while theta < 2 * pi:
	bfield 			= arrow()
	bfield.color 	= color.cyan
	bfield.pos 		= vector(0, 8e-11 * sin(theta), 8e-11 * cos(theta))
	r.append(bfield)

	bfield 			= arrow()
	bfield.color 	= color.cyan
	bfield.pos 		= vector(-2e-10, 8e-11 * sin(theta), 8e-11 * cos(theta))
	r.append(bfield)

	bfield 			= arrow()
	bfield.color 	= color.cyan
	bfield.pos 		= vector(2e-10, 8e-11 * sin(theta), 8e-11 * cos(theta))
	r.append(bfield)

	theta 			= theta + dtheta

## Initializes the arrows for the electric field
re  = []
theta = 0
dtheta = 2*pi/4
while theta < 2 *pi:
	efield 			= arrow()
	efield.color 	= color.orange
	efield.pos 		= vector(0, 8e-11 * sin(theta), 8e-11 * cos(theta))
	re.append(efield)

	efield 			= arrow()
	efield.color 	= color.orange
	efield.pos 		= vector(-2e-10, 8e-11 * sin(theta), 8e-11 * cos(theta))
	re.append(efield)

	efield 			= arrow()
	efield.color 	= color.orange
	efield.pos 		= vector(2e-10, 8e-11 * sin(theta), 8e-11 * cos(theta))
	re.append(efield)
	theta 			= theta + dtheta

# Initial Time
t = 0 #[s]
# Change in time
dt = 1e-16 #[s]
while t < 100 * dt:
	rate(10)
# Updates the position of the proton
	proton.pos = proton.pos + proton.v * dt
# Initializes the index
	j = 0
# Calculates the magnetic and electric field
	while j < len(r):
		robs 	=  r[j].pos - proton.pos
		rhat 	= norm(robs)
		rmag 	= mag(robs)
		B 		= mzofp * (proton.q * cross(proton.v, rhat)) / rmag ** 2
		E       = oofpez * proton.q/rmag**2 * rhat
# Updates the magnetic field arrow
		r[j].axis = B * sf
# Updates the electric field arrow
		re[j].axis = E * sf2
		j = j + 1
	t = t +dt