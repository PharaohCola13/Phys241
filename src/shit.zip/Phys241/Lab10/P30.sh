#!/usr/bin/env bash

# Spencer Riley
# To use, type bash P30.sh into your terminal
# After each plot appears, wait a bit and close out
# Repeat for 30 plots

python P30.py >> P30.out   
python P30.py >> P30.out   
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out   
python P30.py >> P30.out   
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out   
python P30.py >> P30.out   
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out   
python P30.py >> P30.out   
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out   
python P30.py >> P30.out   
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out  
python P30.py >> P30.out  
